package com.example.weatherapp;

import androidx.lifecycle.ViewModel;

public class WeatherDataViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}