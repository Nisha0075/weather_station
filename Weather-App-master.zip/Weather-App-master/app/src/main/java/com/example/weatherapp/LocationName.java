package com.example.weatherapp;

public class LocationName{
    String name;

    public LocationName(){}

    public LocationName(String name){ this.name = name; }

    public String getName(){ return this.name; }
    public void setName(String name){this.name = name;}
}
