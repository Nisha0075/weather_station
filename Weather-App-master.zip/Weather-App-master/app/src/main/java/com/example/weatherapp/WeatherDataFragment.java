package com.example.weatherapp;

import androidx.lifecycle.ViewModelProviders;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class WeatherDataFragment extends Fragment {
    /* TODO: Figure out what the hell this is supposed to be */
    private WeatherDataViewModel mViewModel;

    public static WeatherDataFragment newInstance() {
        return new WeatherDataFragment();
    }

    @Override /* Called to create and asign any (? viewModel ?) variables */
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.weather_data_fragment, container, false);
    }

    @Override /* Called after onCreate() and runs once the view hierarchy is created */
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(WeatherDataViewModel.class);
        // TODO: Use the ViewModel
    }

    /* ??? Create onStart() method ??? */
}